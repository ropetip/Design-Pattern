package strategy;

import strategy.attack.LaserStrategy;
import strategy.attack.RockStrategy;
import strategy.character.IronMan;
import strategy.character.SuperMan;
import strategy.move.FlyStrategy;
import strategy.move.WalkStrategy;

public class GameLaucher {

	public static void main(String[] args) {
		SuperMan superMan = new SuperMan("슈퍼맨");
		IronMan ironMan = new IronMan("아이언맨");
		
		superMan.setAttackStrategy(new RockStrategy());
		ironMan.setAttackStrategy(new LaserStrategy());
		superMan.setMoveStrategy(new WalkStrategy());
		ironMan.setMoveStrategy(new FlyStrategy());
		
		String superMan_name = superMan.getName();
		String ironMan_name = ironMan.getName();
		
		superMan.attack(superMan_name);
		superMan.move(superMan_name);
		ironMan.attack(ironMan_name);
		ironMan.move(ironMan_name);
		
		System.out.println("---------------------------------------");
		System.out.println(ironMan_name + "은 더이상 날지 못한다.");
		// 아이언맨 이동수단을 걷기로 변경
		ironMan.setMoveStrategy(new WalkStrategy());
		ironMan.move(ironMan_name);
	}

}
