package strategy.attack;

// 공격에 대한 인터페이스 
public interface AttackStrategy {
	// 공격한다.
	public void attack();
	// 누가 공격한다.
	public void attack(String name);
}
