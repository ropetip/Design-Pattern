package strategy.attack;

public class LaserStrategy implements AttackStrategy {
	private final String action = "레이저로 공격한다.";
	
	@Override
	public void attack() {
		System.out.println(action);
	}
	
	@Override
	public void attack(String name) {
		System.out.println(name + "은 " + action);
	}
}
