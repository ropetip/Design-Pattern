package strategy.attack;

public class RockStrategy implements AttackStrategy {

	private final String action = "주먹으로 공격한다.";
			
	@Override
	public void attack() {
		System.out.println(action);
	}
	
	@Override
	public void attack(String name) {
		System.out.println(name + "은 " +action);
	}
}
