package strategy.character;

import strategy.attack.AttackStrategy;
import strategy.move.MoveStrategy;

// 캐릭터 클래스
public abstract class Character {
	// 의존성 주입
	private AttackStrategy attackStrategy;
	private MoveStrategy moveStrategy;
	
	private String name;

	public Character(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}
	// ------------------------------------------------------------------------------------------------------------
	public void attack() {
		attackStrategy.attack();
	}
	
	public void attack(String name) {
		attackStrategy.attack(name);
	}
	
	public void setAttackStrategy(AttackStrategy attackStrategy) {
		this.attackStrategy = attackStrategy;
	}
	// ------------------------------------------------------------------------------------------------------------
	public void move() {
		moveStrategy.move();
	}
	
	public void move(String name) {
		moveStrategy.move(name);
	}
	
	public void setMoveStrategy(MoveStrategy moveStrategy) {
		this.moveStrategy = moveStrategy;
	}
	// ------------------------------------------------------------------------------------------------------------
}
