package strategy.character;

public class IronMan extends Character {
	public IronMan(String name) {
		super(name);
	}
}
