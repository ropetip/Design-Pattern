package strategy.character;

public class SuperMan extends Character {
	
	public SuperMan(String name) {
		super(name);
	}
}
