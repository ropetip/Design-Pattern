package strategy.move;

public class FlyStrategy implements MoveStrategy {
	private final String action = "하늘을 난다.";
	
	@Override
	public void move() {
		System.out.println(action);
	}
	
	@Override
	public void move(String name) {
		System.out.println(name + "은 " + action);
	}
}
