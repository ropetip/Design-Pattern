package strategy.move;

// 이동에 대한 인터페이스 
public interface MoveStrategy {
	// 이동한다.
	public void move();
	// 누가 이동한다.
	public void move(String name);
}
