package strategy.move;

public class WalkStrategy implements MoveStrategy {
	private final String action = "걷는다.";
	
	@Override
	public void move() {
		System.out.println(action);
	}

	@Override
	public void move(String name) {
		System.out.println(name + "은 "+action);
	}
}
